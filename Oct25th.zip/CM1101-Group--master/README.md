# CM1101-Group-

# Tasks to do 
 - Count the amount of steps and edit difficulties accourdingly
 - Finish presentation (with script) and assign roles
 

# Github Help
1. Whenever you want to work on the project, make sure to pull the latest version by typing: "git pull"
2. Once you've made some changes in the code, run git status to see which files you've modified by typing: "git status"
3. Add your modified files by typing: "git add file.py"
3. Commit your changes to your local repository by typing: "git commit -m "commit message"
4. Push your changes by typing: "git push"
